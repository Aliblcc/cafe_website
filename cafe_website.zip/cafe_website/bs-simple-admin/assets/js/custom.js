


/*=============================================================
    Authour URI: www.binarytheme.com
    License: Commons Attribution 3.0

    http://creativecommons.org/licenses/by/3.0/

    100% To use For Personal And Commercial Use.
    IN EXCHANGE JUST GIVE US CREDITS AND TELL YOUR FRIENDS ABOUT US
   
    ========================================================  */


(function ($) {
    "use strict";
    var mainApp = {

        main_fun: function () {
           
            /*====================================
              LOAD APPROPRIATE MENU BAR
           ======================================*/
            $(window).bind("load resize", function () {
                if ($(this).width() < 768) {
                    $('div.sidebar-collapse').addClass('collapse')
                } else {
                    $('div.sidebar-collapse').removeClass('collapse')
                }
            });

          
     
        },

        initialization: function () {
            mainApp.main_fun();

        }

    }
    // Initializing ///

    $(document).ready(function () {
        mainApp.main_fun();
    });

}(jQuery));

document.addEventListener("DOMContentLoaded", () => {
    const menuForm = document.getElementById("menu-form");
    const itemList = document.getElementById("item-list");
  
    loadItems();
  
    // Event listener for adding/updating a menu item
    menuForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const name = document.getElementById("item-name").value;
      const image = document.getElementById("item-image").value;
      const price = document.getElementById("item-price").value;
      const description = document.getElementById("item-description").value;
      const filter = document.getElementById("item-filter").value;
  
      const newItem = { name, image, price, description, filter };
  
      addOrUpdateMenuItem(newItem);
      menuForm.reset();
      loadItems();
    });
  
    // Function to add or update a menu item in Local Storage
    function addOrUpdateMenuItem(item) {
      let items = JSON.parse(localStorage.getItem("menuItems")) || [];
      const index = items.findIndex((i) => i.name === item.name);
  
      if (index >= 0) {
        items[index] = item; // Update existing item
      } else {
        items.push(item); // Add new item
      }
  
      localStorage.setItem("menuItems", JSON.stringify(items));
    }
  
    // Function to load items from Local Storage and display them
    function loadItems() {
      const items = JSON.parse(localStorage.getItem("menuItems")) || [];
      itemList.innerHTML = ""; // Clear the existing content
  
      items.forEach((item, index) => {
        const itemElement = document.createElement("div");
        itemElement.classList.add("admin-item");
        itemElement.innerHTML = `
          <p><strong>${item.name}</strong> - ${item.price}₺</p>
          <img src="${item.image}" alt="${item.name}" style="width: 100px;">
          <p>${item.description}</p>
          <p>Category: ${item.filter}</p>
          <button class="edit-item" data-index="${index}">Edit</button>
          <button class="delete-item" data-index="${index}">Delete</button>
        `;
        itemList.appendChild(itemElement);
      });
  
      // Add event listeners for edit and delete buttons
      document.querySelectorAll(".edit-item").forEach(button => {
        button.addEventListener("click", handleEdit);
      });
      document.querySelectorAll(".delete-item").forEach(button => {
        button.addEventListener("click", handleDelete);
      });
    }
  
    // Function to handle editing an item
    function handleEdit(e) {
      const index = e.target.getAttribute("data-index");
      const items = JSON.parse(localStorage.getItem("menuItems"));
      const item = items[index];
  
      // Populate the form with the item's current values for editing
      document.getElementById("item-name").value = item.name;
      document.getElementById("item-image").value = item.image;
      document.getElementById("item-price").value = item.price;
      document.getElementById("item-description").value = item.description;
      document.getElementById("item-filter").value = item.filter;
    }
  
    // Function to handle deleting an item
    function handleDelete(e) {
      const index = e.target.getAttribute("data-index");
      let items = JSON.parse(localStorage.getItem("menuItems"));
  
      items.splice(index, 1); // Remove the item from the array
      localStorage.setItem("menuItems", JSON.stringify(items));
      loadItems(); // Reload the item list after deletion
    }
  
    // Clear all items in Local Storage
    document.getElementById("clear-items").addEventListener("click", () => {
      localStorage.removeItem("menuItems");
      loadItems(); // Clear the displayed list
    });
  
    imageInput.addEventListener("change", (e) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = function (event) {
          selectedImageDataUrl = event.target.result; // Get the data URL
          imagePreview.src = selectedImageDataUrl; // Show the preview
          imagePreview.style.display = "block"; // Display the preview image
        };
        reader.readAsDataURL(file); // Read the file as data URL
      }
    });
    
  });



document.getElementById('add-btn').addEventListener('click', function () {
  const todoInput = document.getElementById('todo-input');
  const todoText = todoInput.value.trim();
  
  if (todoText !== "") {
      addTodoItem(todoText);
      saveTodoItem(todoText); 
      todoInput.value = "";
  } else {
      alert('Please enter a task');
  }
});

function addTodoItem(todoText, isCompleted = false) {
  const li = document.createElement('li');
  li.textContent = todoText;

  if (isCompleted) {
      li.classList.add('completed');
  }

  const deleteBtn = document.createElement('button');
  deleteBtn.textContent = 'Delete';
  deleteBtn.classList.add('delete-btn');

  deleteBtn.addEventListener('click', function () {
      li.remove();
      deleteTodoItem(todoText); 
  });

  li.addEventListener('click', function () {
      li.classList.toggle('completed');
      toggleTodoCompletion(todoText); 
  });

  li.appendChild(deleteBtn);
  document.getElementById('todo-list').appendChild(li);
}


function saveTodoItem(todoText) {
  let todos = JSON.parse(localStorage.getItem('todos')) || [];
  todos.push({ text: todoText, completed: false });
  localStorage.setItem('todos', JSON.stringify(todos));
}


function loadTodoItems() {
  const todos = JSON.parse(localStorage.getItem('todos')) || [];
  todos.forEach(todo => {
      addTodoItem(todo.text, todo.completed);
  });
}


function deleteTodoItem(todoText) {
  let todos = JSON.parse(localStorage.getItem('todos')) || [];
  todos = todos.filter(todo => todo.text !== todoText);
  localStorage.setItem('todos', JSON.stringify(todos));
}


function toggleTodoCompletion(todoText) {
  let todos = JSON.parse(localStorage.getItem('todos')) || [];
  todos = todos.map(todo => {
      if (todo.text === todoText) {
          todo.completed = !todo.completed;
      }
      return todo;
  });
  localStorage.setItem('todos', JSON.stringify(todos));
}


window.addEventListener('load', loadTodoItems);

